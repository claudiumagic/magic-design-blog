---
title: Primul meu articol
date: 2025-01-18
description: De ce am început acest blog
slug: primul-articol
---

# Salut 👋

Aici o să scriu despre parcursul meu, ce învăț, ce construiesc.

## Ce urmează

- proiecte
- greșeli
- lecții
